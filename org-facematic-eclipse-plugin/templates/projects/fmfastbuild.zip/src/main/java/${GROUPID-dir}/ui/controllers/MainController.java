package ${GROUPID}.ui.controllers;

import com.vaadin.ui.UI;
import org.facematic.core.annotations.FmUI;
import org.facematic.core.annotations.FmView;
import org.facematic.core.annotations.FmViewComponent;
import org.facematic.core.mvc.FmBaseController;
import com.vaadin.ui.Component;
// GENERATED_CODE_BEGIN. Do not replace this comment!


@FmView(name="${GROUPID}.ui.views.MainView")
public class MainController implements FmBaseController {
	
// GENERATED_CODE_END. Do not replace this comment!
	
	@FmUI
	UI ui;
	
	@Override
	public void init () {
	   // TODO add your code here
	}
	
}

